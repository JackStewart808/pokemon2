package algorithms.excercise9_24;

class testPower
{
    public static void main(String[] args)
    {
        power test = new power();
        System.out.println(test.pow(2, 0));
        System.out.println(test.pow(2, 3));
        System.out.println(test.pow(2, -3));
        System.out.println(test.pow(0, 1));
        System.out.println(test.pow(-2, 3));
        System.out.println(test.pow(0, -1));




    }
}