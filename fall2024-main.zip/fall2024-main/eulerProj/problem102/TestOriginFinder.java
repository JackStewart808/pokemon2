package eulerProj.problem102;

public class TestOriginFinder
{
    public static void main(String[] args)
    {
        OriginFinder testFinder = new OriginFinder();

        System.out.println(testFinder.findOrigin(-340,495,-153,-910,835,-947));
    }
}