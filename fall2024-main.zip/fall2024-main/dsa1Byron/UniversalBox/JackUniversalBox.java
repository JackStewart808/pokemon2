public class JackUniversalBox <T>
{
    public T thing1;

    public JackUniversalBox(T thing1)
    {
        this.thing1 = thing1;
    }

    public T getT()
    {
        return thing1;
    }
}
