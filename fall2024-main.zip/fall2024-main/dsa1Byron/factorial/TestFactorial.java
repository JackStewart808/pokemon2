package factorial;

public class TestFactorial
{
    public static void main(String[] args)
    {
        Factorial test1 = new Factorial();
        System.out.println(test1.findFact(5));
    }
}