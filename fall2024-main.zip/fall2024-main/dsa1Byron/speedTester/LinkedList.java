package speedTester;

public class LinkedList
{
    private Node head;

    public void add()
    {

        while(head.getNext() != null)
        {
            
        }
    }

}