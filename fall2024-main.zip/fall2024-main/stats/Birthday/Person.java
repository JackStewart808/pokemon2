package stats.Birthday;

public class Person
{
    public int birthday;

    public Person(int birthday)
    {
        this.birthday = birthday;
    }
}