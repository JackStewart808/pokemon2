package stats.pokemonMonte;

public class Pokemon extends Card
{
    private int hp;

    public int getHP()
    {
        return hp;
    }
    public void setHp(int Cardhp)
    {
        hp = Cardhp;
    }
}