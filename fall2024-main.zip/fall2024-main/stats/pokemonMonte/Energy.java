package stats.pokemonMonte;

public class Energy extends Card
{

}
