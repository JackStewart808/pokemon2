package stats.pokemonMonte;

public class Charmander extends Pokemon
{
    public Charmander()
    {
        setHp(70);
    }
}