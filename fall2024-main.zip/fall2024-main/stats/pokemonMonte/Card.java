package stats.pokemonMonte;

public class Card
{
    
}