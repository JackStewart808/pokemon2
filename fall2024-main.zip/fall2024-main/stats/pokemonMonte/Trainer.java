package stats.pokemonMonte;

public class Trainer extends Card
{
    
}