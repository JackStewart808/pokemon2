package stats.pokemonMonte;

public class Candy extends Card
{

}
