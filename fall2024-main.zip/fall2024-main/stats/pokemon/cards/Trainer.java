package stats.pokemon.cards;

public class Trainer extends Card
{
    public void ability()
    {

    }
}