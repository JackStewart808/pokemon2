package stats.pokemon.cards;

public class Card
{
    public String name;

    public void setName(String inputName)
    {
        name = inputName;
    }

    public String getName()
    {
        return name;
    }
}