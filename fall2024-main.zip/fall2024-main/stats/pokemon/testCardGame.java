package stats.pokemon;


public class testCardGame
{
    public static void main(String[] args)
    {
        PokemonGame testGame = new PokemonGame();
        testGame.runGame();
    }
}